<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Product;

class ShippingController extends Controller
{
    public function show(){
        $categories = Category::all();
        $products = Product::all();
        return view('front.shipping', compact('products', 'categories'));
    }
}
