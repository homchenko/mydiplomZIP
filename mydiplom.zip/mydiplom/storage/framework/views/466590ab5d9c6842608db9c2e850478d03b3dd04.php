<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8">
    <title>Gllacy</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&amp;subset=cyrillic" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?> 
  </body>
</html>

<?php /* D:\programs\OSPanel\domains\mydiplom\resources\views/template.blade.php */ ?>