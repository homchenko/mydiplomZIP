
<?php echo $__env->make('adminlte::login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\programs\OSPanel\domains\mydiplom\resources\views/auth/login.blade.php */ ?>