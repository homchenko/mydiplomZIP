<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Создать товар</h1>

    <?php echo Form::open(['route' => 'products.store']); ?>

    <div class="form-group">
        <?php echo e(Form::label('slug', 'Slug')); ?>

        <?php echo e(Form::text('slug', null, ['class' =>'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('title', 'Title')); ?>

        <?php echo e(Form::text('title', null, ['class' =>'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('image', 'Image')); ?>

        <?php echo e(Form::textarea('image', null, ['class' =>'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('category_id', 'Category_id')); ?>

        <?php echo e(Form::textarea('category_id', null, ['class' =>'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('price', 'Price')); ?>

        <?php echo e(Form::text('price', null, ['class' =>'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('fat', 'Fat')); ?>

        <?php echo e(Form::text('fat', null, ['class' =>'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('filter', 'Filter')); ?>

        <?php echo e(Form::text('filter', null, ['class' =>'form-control'])); ?>

    </div>

    <?php echo e(Form::submit('Создать товар', ['class' => 'btn btn-primary'])); ?>

  
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\programs\OSPanel\domains\mydiplom\resources\views/products/create.blade.php */ ?>