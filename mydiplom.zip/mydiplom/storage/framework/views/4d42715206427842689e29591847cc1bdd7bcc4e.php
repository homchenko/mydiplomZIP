<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
    
    <table class="table table-striped table-bordered table-hover">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Image</th>
            <th>Price</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->title); ?></td>
                <td><?php echo e($product->image); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit', [$product->id])); ?>" class="btn btn-success">
                        <span class="fa fa-edit"></span> Редактировать</a>
                </td>
                <td>
                <?php echo Form::open(['method' => 'DELETE', 'route' => ['products.destroy', $product->id]]); ?>

                <?php echo Form::submit('Удалить', ['class' => 'btn btn-danger', 'onclick' => 'return confirm("Вы уверены?");']); ?>

                <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\programs\OSPanel\domains\mydiplom\resources\views/products/index.blade.php */ ?>