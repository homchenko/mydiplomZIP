
<?php echo $__env->make('adminlte::passwords.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\programs\OSPanel\domains\mydiplom\resources\views/auth/passwords/email.blade.php */ ?>