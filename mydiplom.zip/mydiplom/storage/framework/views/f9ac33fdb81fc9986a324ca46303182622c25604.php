
<?php echo $__env->make('adminlte::register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\programs\OSPanel\domains\mydiplom\resources\views/auth/register.blade.php */ ?>